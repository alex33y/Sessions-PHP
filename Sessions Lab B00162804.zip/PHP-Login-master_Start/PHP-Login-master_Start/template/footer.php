<footer class="footer">
    <p>Web dev serverside</p> <!-- code derived from https://github.com/mariofont -->
</footer>

</div>

</body>
</html>
